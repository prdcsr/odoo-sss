Creating a new preview file
~~~~~~~~~~~~~~~~~~~~~~~~~~~

You need to add the configuration in three places:

* Function `_checkAttachment` and `_hasPreview` from `mail.DocumentViewer` on
  Javascript
* Qweb template `DocumentViewer.Content`

As an example, you can check `mail_preview_audio`.
