This module has two goals:

*  Define a unique system for inheritance that will allow to introduce more
   types for the preview.
*  Define a new widget that will allow to show the preview.
