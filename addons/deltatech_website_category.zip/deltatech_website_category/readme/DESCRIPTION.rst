Features:
 - Arhivarea categorii publice
 - Cautare si grupare produse dupa categoria publica
