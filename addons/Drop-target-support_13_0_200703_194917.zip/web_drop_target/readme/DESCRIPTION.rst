This module extends the functionality of the web client to support dropping local files into the web client.

By default, an attachment will be created when dropping a file on a form.

Further, this module is meant as a base drag&drop module supporting other actions after some file is dropped so that other modules can add more features.
