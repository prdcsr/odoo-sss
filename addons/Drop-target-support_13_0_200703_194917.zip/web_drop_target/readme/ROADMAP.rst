* dropping on list or kanban views would be nice too
* handle multiple files
* add an upload progress meter for huge files
* trigger custom events about different stages of the drop operation for other addons to hook in
* Install document module to display attachments in the sidebar
