11.0.2.5.0 (2019-04-26)
~~~~~~~~~~~~~~~~~~~~~~~

* In the Trial Balance you have an option to hide parent hierarchy levels

11.0.2.4.1 (2019-01-08)
~~~~~~~~~~~~~~~~~~~~~~~

* Handle better multicompany behaviour
* Improve how title appears in the reports
* Improve performance in General Ledger


11.0.2.3.1 (2018-11-29)
~~~~~~~~~~~~~~~~~~~~~~~

* In the Trial Balance you can apply a filter by hierarchy levels
* In the General Ledger you can apply a filter by Analytic Tag
* In the Journal Ledger the field 'Journal' is now optional
