* Alexis de Lattre <alexis.delattre@akretion.com>
* ForgeFlow S.L. <contact@forgeflow.com>
  * Jordi Ballester
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Tecnativa <https://www.tecnativa.com>
  * Pedro M. Baeza
* Spacefoot <https://www.spacefoot.com>
  * Quentin Delcourte
