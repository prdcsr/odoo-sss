To create TXT/CSV/XLSX statement sheet columns mapping:

#. Open *Invoicing > Configuration > Accounting > Statement Sheet Mappings*
#. Create mapping(s) according to your online banking software statement format
