To use this module, you need to:

#. Get statement in TXT/CSV or XLSX from your online banking software
#. Go to Odoo and and import the statement file, selecting corresponding format
