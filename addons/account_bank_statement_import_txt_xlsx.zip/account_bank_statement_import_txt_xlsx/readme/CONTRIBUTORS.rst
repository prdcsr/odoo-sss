* Alexis de Lattre <alexis.delattre@akretion.com>
* Sebastien BEAU <sebastien.beau@akretion.com>
* Tecnativa (https://www.tecnativa.com)

  * Vicent Cubells <vicent.cubells@tecnativa.com>
  * Victor M.M. Torres <victor.martin@tecnativa.com>

* ForgeFlow (https://www.forgeflow.com)

  * Jordi Ballester Alomar <jordi.ballester@forgeflow.com>
  * Miquel Raïch Regué <miquel.raich@forgeflow.com>

* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>
