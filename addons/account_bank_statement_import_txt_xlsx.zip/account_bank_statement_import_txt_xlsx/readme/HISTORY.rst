12.0.2.0.0
~~~~~~~~~~

* [BREAKING] New mapping, please review mappings after upgrade.
* [BREAKING] Different bank accounts have to be used per each currency.
* [ADD] Support for both Statement and Activity reports.
* [ADD] Separate fee and currency exchange parsing.
