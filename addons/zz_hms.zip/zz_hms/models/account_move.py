from odoo import api, fields, models, _


class AccountMove(models.Model):
    _inherit = 'account.move' 

    def _get_report_base_filename(self):
        if any(not move.is_invoice(include_receipts=True) for move in self):
            raise UserError(_("Only invoices could be printed."))
        return self._get_move_display_name()
