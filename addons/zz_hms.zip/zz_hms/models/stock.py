from datetime import datetime, timedelta
from collections import defaultdict

from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, float_compare
from odoo.exceptions import UserError

class Picking(models.Model):
    _inherit = "stock.picking"

    no_container = fields.Char(string='No Container')
    