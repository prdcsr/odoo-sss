Adds a configurable *type* on the purchase orders.
This type can be used in filters and groupbys.
