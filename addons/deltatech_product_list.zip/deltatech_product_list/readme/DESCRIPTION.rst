Features:
 - defining product lists
