# -*- coding: utf-8 -*-res_user
from . import product