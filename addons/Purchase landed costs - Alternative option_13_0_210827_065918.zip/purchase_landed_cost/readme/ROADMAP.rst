* Ability to add expenses in multi currency.
* Purchase distribution report.
* Upgrade cost price of products based on the costs.
