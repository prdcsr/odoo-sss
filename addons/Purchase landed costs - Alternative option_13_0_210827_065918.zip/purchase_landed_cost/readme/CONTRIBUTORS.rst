* Joaquín Gutierrez <joaquing.pedrosa@gmail.com>
* Santi Argüeso <santi@comunitea.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Vicent Cubells
  * Ernesto Tejeda
