* Go to *Settings / Mass Editing / Mass Editing* and configure the object and fields for Mass Editing.

* Select the object and add the fields of that object on which you want to apply mass editing.

.. image:: ../static/description/mass_editing_form.png
   :width: 70%

* *Add Action*: As shown in figure click on *Add Sidebar Button* to add mass editing option in *Action* option in action.


**Options**

* You can limit the mass editing by a domain.

* you can limit the access to the option to a given group.

* you can add an extra message that will be displayed in the wizard.
