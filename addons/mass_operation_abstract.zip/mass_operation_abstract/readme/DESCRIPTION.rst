This module provides generic tools to develop modules that process mass
operations on any models.
