* Propose this module in the OCA. (server-tools repository)

* refactor ``mass_editing`` and ``mass_sorting`` OCA modules to depend on
  this module.

* Develop new modules like:

1. ``mass_scripting`` to have the possibility to execute custom python code
   on any model, for selected items.
