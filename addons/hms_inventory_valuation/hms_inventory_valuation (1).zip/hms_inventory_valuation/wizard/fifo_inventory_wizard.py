from odoo import models, fields, api
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from datetime import datetime
import io
import base64
import xlsxwriter


class FifoInventoryValuationWizard(models.TransientModel):
    _name = 'fifo.inventory.valuation.wizard'
    _description = 'FIFO Inventory Valuation Wizard'

    valuation_date = fields.Date(string='Valuation Date', default=fields.Date.context_today, required=True)
    location_id = fields.Many2one('stock.location', string='Location', domain=[('usage', '=', 'internal')])
    include_child = fields.Boolean(string='Include Child Locations', default=True)
    show_detailed_operation = fields.Boolean(string='Show Detailed Operation')

    @api.onchange('location_id')
    def _onchange_location_id(self):
        self.include_child = bool(self.location_id)

    def _get_locations(self):
        if self.location_id:
            if self.include_child:
                return self.location_id.search([('id', 'child_of', self.location_id.id)])
            return self.location_id
        return self.env['stock.location'].search([('usage', '=', 'internal')])

    def _get_valuation_lines(self):
        StockValuationLayer = self.env['stock.valuation.layer']
        locations = self._get_locations().ids
        layers = StockValuationLayer.search([
            ('create_date', '<=', self.valuation_date.strftime(DEFAULT_SERVER_DATE_FORMAT)),
            ('custom_dest_location_id', 'in', locations),
        ])
        grouped = {}
        detailed = {}
        for layer in layers:
            product = layer.product_id
            location = layer.custom_dest_location_id
            key = (product.id, location.id)
            qty = layer.quantity
            value = layer.value
            if qty == 0:
                continue
            if key not in grouped:
                grouped[key] = {'product': product, 'location': location, 'qty': 0.0, 'value': 0.0}
                detailed[key] = []
            grouped[key]['qty'] += qty
            grouped[key]['value'] += value
            if self.show_detailed_operation:
                detailed[key].append({
                    'picking': layer.stock_move_id.picking_id.name or '',
                    'qty': qty,
                    'uom': product.uom_id.name,
                    'unit_cost': value / qty if qty else 0.0,
                    'total_cost': value,
                })
        return grouped, detailed

    def action_view_report(self):
        grouped, detailed = self._get_valuation_lines()
        return self.env.ref('hms_inventory_valuation.action_fifo_inventory_report').report_action(self, data={
            'grouped': grouped,
            'detailed': detailed,
            'show_details': self.show_detailed_operation,
            'date': self.valuation_date.strftime('%Y-%m-%d'),
        })

    def action_export_excel(self):
        grouped, detailed = self._get_valuation_lines()
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('FIFO Valuation')

        bold = workbook.add_format({'bold': True})
        sheet.write(0, 0, 'Product Code', bold)
        sheet.write(0, 1, 'Product Name', bold)
        sheet.write(0, 2, 'UoM', bold)
        sheet.write(0, 3, 'Qty', bold)
        sheet.write(0, 4, 'Value', bold)
        sheet.write(0, 5, 'Location', bold)

        row = 1
        for key, line in grouped.items():
            sheet.write(row, 0, line['product'].default_code or '')
            sheet.write(row, 1, line['product'].name)
            sheet.write(row, 2, line['product'].uom_id.name)
            sheet.write(row, 3, line['qty'])
            sheet.write(row, 4, line['value'])
            sheet.write(row, 5, line['location'].complete_name)
            row += 1

        workbook.close()
        output.seek(0)
        export_id = self.env['ir.attachment'].create({
            'name': f'FIFO_Inventory_Valuation_{self.valuation_date}.xlsx',
            'type': 'binary',
            'datas': base64.b64encode(output.read()),
            'res_model': self._name,
            'res_id': self.id,
        })
        output.close()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{export_id.id}?download=true',
            'target': 'new',
        }