As this module only depends on the *product* module and that module doesn't provide any menu entry, this module lacks a menu entry for H.S. Codes. A menu entry for H.S. codes is provided by the module *product_harmonized_system_stock*.

Once the H.S. codes are created, you will be able to set the H.S. code on an product (under the *Information* tab) or on a product category. On the product form, you will also be able to set the *Country of Origin* of a product (for example, if the product is *made in China*, select *China* as *Country of Origin*).
