* Alexis de Lattre, Akretion <alexis.delattre@akretion.com>
* Luc De Meyer, Noviat <info@noviat.com>
* Kumar Aberer, brain-tec AG <kumar.aberer@braintec-group.com>
