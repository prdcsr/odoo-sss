This module is NOT compatible with the *account_intrastat* module from Odoo Enterprise.
