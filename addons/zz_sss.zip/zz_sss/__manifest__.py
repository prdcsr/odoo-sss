{
  'name': 'SSS Addons',
  'author': 'SSS Group',
  'version': '0.1',
  'depends': ['account','purchase'],
  'data': [
    'views/purchase_requisition_form.xml',
    #'views/stock_picking_form.xml',
    #'views/sale_order_form.xml',    
    #'views/view_pos_config.xml',
    #'views/view_pos_order.xml',
    #'views/product_view.xml',    
    #'views/templates.xml',
    #'wizard/stock_label_view.xml',
  ],
  'qweb': [
  ],
  'sequence': 3,
  'auto_install': False,
  'installable': True,
  'application': True,
  'category': 'SSS Odoo Addons',
  'summary': 'Odoo Addons Special For SSS Group',
  'license': 'OPL-1',
  'website': 'https://sss-id.yasukapower.com/',
  'description': '-'
}
