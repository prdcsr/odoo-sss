# Copyright 2020 Carlos Roca <carlos.roca@tecnativa.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from odoo import api, fields, models


class ProductPrintingQty(models.TransientModel):
    _name = "stock.picking.line.print"
    _rec_name = "product_id"
    _description = "Print Picking Line"

    product_id = fields.Many2one(
        "product.product",
        string="Product",
        required=True,
        domain="[('id', '=', product_id)]",
    )
    quantity = fields.Float("Quantity", digits="Product Unit of Measure", required=True)
    label_qty = fields.Integer("Quantity of Labels")
    uom_id = fields.Many2one(
        "uom.uom",
        string="Unit of Measure",
        related="move_line_id.product_uom_id",
        readonly=False,
    )
    lot_id = fields.Many2one("stock.production.lot", string="Lot/Serial Number")
    wizard_id = fields.Many2one("stock.picking.print", string="Wizard")
    move_line_id = fields.Many2one("stock.move.line", "Move")    
    qty_on_label = fields.Integer("Quantity on Labels")


class WizStockBarcodeSelectionPrinting(models.TransientModel):
    _name = "stock.picking.print"
    _description = "Wizard to select how many barcodes have to be printed"

    @api.model
    def default_get(self, fields):
        ctx = self.env.context.copy()
        res = super().default_get(fields)
        if ctx.get("active_ids") and ctx.get("active_model") == "stock.picking":
            picking_ids = self.env["stock.picking"].browse(ctx.get("active_ids"))
            res.update({"picking_ids": picking_ids.ids})
        return res

    picking_ids = fields.Many2many("stock.picking")
    product_print_moves = fields.One2many(
        "stock.picking.line.print", "wizard_id", "Moves"
    )
    barcode_format = fields.Selection(
        selection=[("gs1_128", "Display GS1_128 format for barcodes")],
        string="Barcode format",
        default=lambda self: self.env.company.barcode_default_format,
    )
    type_label = fields.Selection([("galaxy","Galaxy"),("glx_good","GLX GOOD"),("polos","Polos"),("noheader","No Header"),("sinarkasih","Sinar Kasih")], string='Type Of Label')

    @api.onchange("picking_ids")
    def _onchange_picking_ids(self):
        product_print_moves = []
        line_fields = [f for f in self.env["stock.picking.line.print"]._fields.keys()]
        product_print_moves_data_tmpl = self.env[
            "stock.picking.line.print"
        ].default_get(line_fields)
        for picking_id in self.picking_ids.ids:
            picking = self.env["stock.picking"].browse(picking_id)
            for move_line in picking.move_line_ids:
                product_print_moves_data = dict(product_print_moves_data_tmpl)
                product_print_moves_data.update(
                    self._prepare_data_from_move_line(move_line)
                )
                if product_print_moves_data:
                    product_print_moves.append((0, 0, product_print_moves_data))
        if self.picking_ids:
            self.product_print_moves = product_print_moves

    @api.model
    def _prepare_data_from_move_line(self, move_line):
        if move_line.product_id.barcode:
            return {
                "product_id": move_line.product_id.id,
                "quantity": move_line.product_uom_qty,
                "label_qty": 1,
                "qty_on_label": 1,
                "move_line_id": move_line.id,               
                "uom_id": move_line.product_uom_id.id,
                "lot_id": move_line.lot_id,
            }
        else:
            return {}

    def print_labels(self):
        print_move = self.product_print_moves.filtered(lambda p: p.label_qty > 0)
        if print_move:
            return self.env.ref(
                "stock_picking_product_barcode_report.action_label_barcode_report"
            ).report_action(self.product_print_moves)
