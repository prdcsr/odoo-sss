#. Go to 'Settings > Inventory > Barcode format' and select 'Display GS1_128 format for
   barcodes' or let it blank for normal use of barcodes on Odoo.
