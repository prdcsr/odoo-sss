#. Create a new transfer with a product with 'Barcode'.
#. Validate it.
#. Click on 'Print > Print Barcode Labels'.
#. Select how many labels do you want for each product.
#. Click on 'Print' and open the pdf with the labels.
