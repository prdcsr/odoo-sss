
- Configure product list:
      - Sales -> Products -> Product list

.. figure:: static/description/img1.png
    :width: 90%
    :class: img-responsive center-block
    :alt: Product list

- Create a new product list and define domain :

.. figure:: static/description/img2.png
    :width: 90%
    :class: img-responsive center-block
    :alt: Product list details

- Insert snipped in webpage

.. figure:: static/description/img3.png
    :class: img-responsive center-block
    :alt: Insert snipped

- Select product list:

.. figure:: static/description/img4.png
    :width: 90%
    :class: img-responsive center-block
    :alt: Select list

- Edit description for product list in website:

.. figure:: static/description/img5.png
    :width: 90%
    :class: img-responsive center-block
    :alt: Edit

- Save page:

.. figure:: static/description/img6.png
    :width: 90%
    :class: img-responsive center-block
    :alt: Result
